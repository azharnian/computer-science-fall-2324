#  ANAS  #
#  Make sure you had python interpreter min Python.10
## check your system

## windows
python --version

## mac / linux
python3 --version

## output
Python 3.10.6

#  Go to the project folder
#  Install all library using pip

## Windows
pip install -r requirements.txt

## Mac
python3 -m pip install -r requirements.txt

#  Run the program

## Windows
python app.py

## Mac
python3 app.py

#  Open your browser go to http://127.0.0.1:5000/
